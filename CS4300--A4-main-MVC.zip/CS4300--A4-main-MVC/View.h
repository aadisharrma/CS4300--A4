#pragma once
#include <glad/glad.h>
#include <glm/glm.hpp>
#include "Model.h"
#include "ShaderProgram.h"

class DroneView {
public:
    DroneView();
    ~DroneView();
    
    // Initialize OpenGL resources
    void init();
    
    // Draw the drone using the model's state
    void drawDrone(const DroneModel& model);
    
    // Camera management
    enum CameraMode {
        CAMERA_ANGLED,
        CAMERA_TOP_DOWN,
        CAMERA_ORBIT,
        CAMERA_FIRST_PERSON
    };
    
    void setCameraMode(CameraMode mode);
    CameraMode getCameraMode() const;
    
    // Update camera (for orbit camera)
    void updateCamera(float dt, const DroneModel& model);
    
    // Get view matrix for current camera mode
    glm::mat4 getViewMatrix(const DroneModel& model) const;
    
    // Get projection matrix
    glm::mat4 getProjectionMatrix(int windowWidth, int windowHeight) const;
    
    // Cleanup resources
    void cleanup();
    
    // Getter for shader program
    GLuint getShaderProgram() const;
    
private:
    // OpenGL resources
    GLuint shaderProgram;
    GLuint cubeVAO;
    GLuint sphereVAO;
    GLuint sphereVBO;
    int sphereNumVerts;
    bool geometryInitialized;
    
    // Camera related
    CameraMode currentCamera;
    float chopperAngle;
    float chopperSpeed;
    
    void initShaders();
    
    // Helper functions
    void initSphereGeometry();
    void initCubeGeometry();
    void drawCube(const glm::mat4& model);
    void drawSphere(const glm::mat4& model);
};
