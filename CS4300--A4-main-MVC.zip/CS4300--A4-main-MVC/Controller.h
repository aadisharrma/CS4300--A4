#pragma once

#include <GLFW/glfw3.h>
#include "Model.h"
#include "View.h"

class DroneController {
public:
    DroneController(DroneModel& model, DroneView& view);
    ~DroneController();
    
    // Process input and update the model
    void processInput(GLFWwindow* window, float dt);
    
    // Handle window resize
    static void framebufferSizeCallback(GLFWwindow* window, int width, int height);
    
    // Main update loop (call once per frame)
    void update(float dt);
    
    // Set window size
    void setWindowSize(int width, int height);
    
    // Get window dimensions
    int getWindowWidth() const;
    int getWindowHeight() const;
    
private:
    // References to model and view
    DroneModel& model;
    DroneView& view;
    
    // Window dimensions
    int windowWidth;
    int windowHeight;
    
    // Callback setup (for GLFW)
    static DroneController* instance;
    static void framebufferSizeCallbackDispatcher(GLFWwindow* window, int width, int height);
};
