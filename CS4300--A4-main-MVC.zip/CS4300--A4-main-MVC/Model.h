#pragma once
#include <glm/glm.hpp>

class DroneModel {
public:
    DroneModel();
    
    // Getters
    glm::vec3 getPosition() const;
    float getPropAngle() const;
    float getRollAngle() const;
    float getYaw() const;
    float getPitch() const;
    bool isRolling() const;
    float getPropSpeed() const;
    
    // Setters
    void setPosition(const glm::vec3& position);
    void setYaw(float yaw);
    void setPitch(float pitch);
    void setPropSpeed(float speed);
    
    // Actions
    void startRoll();
    void resetDrone();
    void moveForward(float dt);
    void moveBackward(float dt);
    void turnLeft(float dt);
    void turnRight(float dt);
    void pitchUp(float dt);
    void pitchDown(float dt);
    void increaseSpeed(float dt);
    void decreaseSpeed(float dt);
    
    // Update state (called each frame)
    void update(float dt);
    
    // Utility functions
    glm::vec3 getForwardVector() const;
    
private:
    // State variables
    glm::vec3 position;
    float propAngle;
    float propSpeed;
    float rollAngle;
    float rollSpeed;
    float yaw;
    float pitch;
    float moveFactor;
    float turnRate;
};
