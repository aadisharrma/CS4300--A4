#include "Controller.h"

// Initialize static member
DroneController* DroneController::instance = nullptr;

DroneController::DroneController(DroneModel& model, DroneView& view)
    : model(model), view(view), windowWidth(800), windowHeight(600)
{
    // Save instance for callbacks
    instance = this;
}

DroneController::~DroneController() {
    // Clean up the instance
    if (instance == this) {
        instance = nullptr;
    }
}

void DroneController::processInput(GLFWwindow* window, float dt) {
    // Close with ESC
    if (glfwGetKey(window, GLFW_KEY_ESCAPE) == GLFW_PRESS)
        glfwSetWindowShouldClose(window, true);

    // Speed up/slow down propellers with 'f' and 's' keys
    if (glfwGetKey(window, GLFW_KEY_F) == GLFW_PRESS)
        model.adjustPropSpeed(50.0f * dt);
    if (glfwGetKey(window, GLFW_KEY_S) == GLFW_PRESS)
        model.adjustPropSpeed(-50.0f * dt);

    // Single 360 roll if not already rolling - using 'j' key
    if (glfwGetKey(window, GLFW_KEY_J) == GLFW_PRESS && !model.isRolling())
        model.startRoll();

    // Move forward/back with '='/'-'
    if (glfwGetKey(window, GLFW_KEY_EQUAL) == GLFW_PRESS)
        model.moveForward(dt);
    if (glfwGetKey(window, GLFW_KEY_MINUS) == GLFW_PRESS)
        model.moveBackward(dt);

    // Turn with arrow keys
    if (glfwGetKey(window, GLFW_KEY_LEFT) == GLFW_PRESS)
        model.turnLeft(dt);
    if (glfwGetKey(window, GLFW_KEY_RIGHT) == GLFW_PRESS)
        model.turnRight(dt);
    if (glfwGetKey(window, GLFW_KEY_UP) == GLFW_PRESS)
        model.pitchUp(dt);
    if (glfwGetKey(window, GLFW_KEY_DOWN) == GLFW_PRESS)
        model.pitchDown(dt);

    // Reset with 'r' key
    if (glfwGetKey(window, GLFW_KEY_R) == GLFW_PRESS)
        model.reset();

    // Switch cameras
    if (glfwGetKey(window, GLFW_KEY_0) == GLFW_PRESS)
        view.setCameraMode(DroneView::CAMERA_ANGLED);
    if (glfwGetKey(window, GLFW_KEY_1) == GLFW_PRESS)
        view.setCameraMode(DroneView::CAMERA_TOP_DOWN);
    if (glfwGetKey(window, GLFW_KEY_2) == GLFW_PRESS)
        view.setCameraMode(DroneView::CAMERA_ORBIT);
    if (glfwGetKey(window, GLFW_KEY_3) == GLFW_PRESS)
        view.setCameraMode(DroneView::CAMERA_FIRST_PERSON);
}

void DroneController::framebufferSizeCallback(GLFWwindow* window, int width, int height) {
    windowWidth = width;
    windowHeight = height;
    glViewport(0, 0, width, height);
}

void DroneController::framebufferSizeCallbackDispatcher(GLFWwindow* window, int width, int height) {
    if (instance) {
        instance->framebufferSizeCallback(window, width, height);
    }
}

void DroneController::update(float dt) {
    // Update model
    model.update(dt);
    
    // Update camera
    view.updateCamera(dt, model);
}

void DroneController::setWindowSize(int width, int height) {
    windowWidth = width;
    windowHeight = height;
}

int DroneController::getWindowWidth() const {
    return windowWidth;
}

int DroneController::getWindowHeight() const {
    return windowHeight;
}
