#include "model.h"
#include <glm/gtc/matrix_transform.hpp>
#include <cmath>

DroneModel::DroneModel() :
    position(0.0f, 1.0f, 0.0f),
    propAngle(0.0f),
    propSpeed(180.0f),
    isRolling(false),
    rollAngle(0.0f),
    rollSpeed(180.0f),
    yaw(45.0f),
    pitch(0.0f),
    moveFactor(0.01f),
    turnRate(90.0f)
{
}

glm::vec3 DroneModel::getPosition() const {
    return position;
}

float DroneModel::getPropAngle() const {
    return propAngle;
}

float DroneModel::getRollAngle() const {
    return rollAngle;
}

float DroneModel::getYaw() const {
    return yaw;
}

float DroneModel::getPitch() const {
    return pitch;
}

bool DroneModel::isRolling() const {
    return isRolling;
}

float DroneModel::getPropSpeed() const {
    return propSpeed;
}

void DroneModel::setPosition(const glm::vec3& pos) {
    position = pos;
}

void DroneModel::setYaw(float y) {
    yaw = y;
}

void DroneModel::setPitch(float p) {
    pitch = p;
}

void DroneModel::setPropSpeed(float speed) {
    propSpeed = speed;
}

void DroneModel::startRoll() {
    if (!isRolling) {
        isRolling = true;
        rollAngle = 0.0f;
    }
}

void DroneModel::resetDrone() {
    position = glm::vec3(0.0f, 1.0f, 0.0f);
    yaw = 45.0f;
    pitch = 0.0f;
    isRolling = false;
    rollAngle = 0.0f;
    propSpeed = 180.0f;
}

void DroneModel::moveForward(float dt) {
    float dist = propSpeed * moveFactor * dt;
    position += getForwardVector() * dist;
}

void DroneModel::moveBackward(float dt) {
    float dist = propSpeed * moveFactor * dt;
    position -= getForwardVector() * dist;
}

void DroneModel::turnLeft(float dt) {
    yaw -= turnRate * dt;
}

void DroneModel::turnRight(float dt) {
    yaw += turnRate * dt;
}

void DroneModel::pitchUp(float dt) {
    pitch += turnRate * dt;
}

void DroneModel::pitchDown(float dt) {
    pitch -= turnRate * dt;
}

void DroneModel::increaseSpeed(float dt) {
    propSpeed += 50.0f * dt;
}

void DroneModel::decreaseSpeed(float dt) {
    propSpeed -= 50.0f * dt;
    if (propSpeed < 0.0f) propSpeed = 0.0f;
}

void DroneModel::update(float dt) {
    // Update propeller angle
    propAngle += propSpeed * dt;
    if (propAngle > 360.0f)
        propAngle = fmod(propAngle, 360.0f);
    
    // Update roll
    if (isRolling) {
        rollAngle += rollSpeed * dt;
        if (rollAngle >= 360.0f) {
            rollAngle = 0.0f;
            isRolling = false;
        }
    }
}

glm::vec3 DroneModel::getForwardVector() const {
    // If yaw=0 => facing +Z in your local space
    glm::vec3 baseForward(0.0f, 0.0f, 1.0f);
    glm::mat4 transform(1.0f);
    
    // Yaw around Y, then pitch around X
    transform = glm::rotate(transform, glm::radians(yaw), glm::vec3(0, 1, 0));
    transform = glm::rotate(transform, glm::radians(pitch), glm::vec3(1, 0, 0));
    
    glm::vec4 dir4 = transform * glm::vec4(baseForward, 0.0f);
    return glm::normalize(glm::vec3(dir4));
}
