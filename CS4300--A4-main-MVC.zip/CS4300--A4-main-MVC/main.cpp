#include <glad/glad.h>
#include <GLFW/glfw3.h>
#include <iostream>

#include "Model.h"
#include "View.h"
#include "Controller.h"

int main() {
    // Initialize GLFW
    if (!glfwInit()) {
        std::cerr << "Failed to initialize GLFW\n";
        return -1;
    }
    
    // Configure GLFW
    glfwWindowHint(GLFW_CONTEXT_VERSION_MAJOR, 3);
    glfwWindowHint(GLFW_CONTEXT_VERSION_MINOR, 3);
    glfwWindowHint(GLFW_OPENGL_CORE_PROFILE, GLFW_OPENGL_CORE_PROFILE);
    
    // Create window
    GLFWwindow* window = glfwCreateWindow(800, 600,
        "Drone: Start Facing Camera, R to Reset, 1=TopDown, 2=Orbit, 3=FP",
        nullptr, nullptr);
    if (!window) {
        std::cerr << "Failed to create GLFW window\n";
        glfwTerminate();
        return -1;
    }
    glfwMakeContextCurrent(window);
    
    // Initialize GLAD
    if (!gladLoadGLLoader((GLADloadproc)glfwGetProcAddress)) {
        std::cerr << "Failed to initialize GLAD\n";
        glfwTerminate();
        return -1;
    }
    
    // Enable depth testing
    glEnable(GL_DEPTH_TEST);
    
    // Create MVC components
    DroneModel model;
    DroneView view;
    DroneController controller(model, view);
    
    // Set up callback
    glfwSetFramebufferSizeCallback(window, DroneController::framebufferSizeCallbackDispatcher);
    
    // Initialize view
    view.init();
    
    // Main loop variables
    float lastTime = (float)glfwGetTime();
    
    // Main loop
    while (!glfwWindowShouldClose(window)) {
        // Calculate delta time
        float currentTime = (float)glfwGetTime();
        float dt = currentTime - lastTime;
        lastTime = currentTime;
        
        // Process input
        controller.processInput(window, dt);
        
        // Update the model and view
        controller.update(dt);
        
        // Render
        view.render(model, controller.getWindowWidth(), controller.getWindowHeight());
        
        // Swap buffers and poll events
        glfwSwapBuffers(window);
        glfwPollEvents();
    }
    
    // Clean up
    view.cleanup();
    
    // Terminate GLFW
    glfwDestroyWindow(window);
    glfwTerminate();
    
    return 0;
}
