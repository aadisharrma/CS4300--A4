#include "View.h"
#include "ShaderProgram.h"
#include <glm/gtc/matrix_transform.hpp>
#include <glm/gtc/type_ptr.hpp>
#include <vector>
#include <cmath>
#include <iostream>

DroneView::DroneView() :
    shaderProgram(0),
    cubeVAO(0),
    sphereVAO(0),
    sphereVBO(0),
    sphereNumVerts(0),
    geometryInitialized(false),
    currentCamera(CAMERA_ANGLED),
    chopperAngle(0.0f),
    chopperSpeed(30.0f)
{
}

DroneView::~DroneView() {
    cleanup();
}

void DroneView::init() {
    // Create shader program
    static const char* vertexSrc = R"(
    #version 330 core
    layout(location=0) in vec3 aPos;
    uniform mat4 model;
    uniform mat4 view;
    uniform mat4 projection;
    void main()
    {
        gl_Position = projection * view * model * vec4(aPos, 1.0);
    }
    )";

    static const char* fragmentSrc = R"(
    #version 330 core
    out vec4 FragColor;
    uniform vec3 objectColor;
    void main()
    {
        FragColor = vec4(objectColor, 1.0);
    }
    )";

    shaderProgram = createShaderProgram(vertexSrc, fragmentSrc);
    
    // Initialize geometry
    initCubeGeometry();
    initSphereGeometry();
    
    geometryInitialized = true;
}

void DroneView::initCubeGeometry() {
    if (cubeVAO != 0) return;
    
    float vertices[] = {
        // front
        -0.5f, -0.5f,  0.5f,
         0.5f, -0.5f,  0.5f,
         0.5f,  0.5f,  0.5f,
         0.5f,  0.5f,  0.5f,
        -0.5f,  0.5f,  0.5f,
        -0.5f, -0.5f,  0.5f,

        // back
        -0.5f, -0.5f, -0.5f,
        -0.5f,  0.5f, -0.5f,
         0.5f,  0.5f, -0.5f,
         0.5f,  0.5f, -0.5f,
         0.5f, -0.5f, -0.5f,
        -0.5f, -0.5f, -0.5f,

        // left
        -0.5f,  0.5f,  0.5f,
        -0.5f,  0.5f, -0.5f,
        -0.5f, -0.5f, -0.5f,
        -0.5f, -0.5f, -0.5f,
        -0.5f, -0.5f,  0.5f,
        -0.5f,  0.5f,  0.5f,

        // right
         0.5f,  0.5f,  0.5f,
         0.5f, -0.5f,  0.5f,
         0.5f, -0.5f, -0.5f,
         0.5f, -0.5f, -0.5f,
         0.5f,  0.5f, -0.5f,
         0.5f,  0.5f,  0.5f,

        // top
        -0.5f,  0.5f, -0.5f,
        -0.5f,  0.5f,  0.5f,
         0.5f,  0.5f,  0.5f,
         0.5f,  0.5f,  0.5f,
         0.5f,  0.5f, -0.5f,
        -0.5f,  0.5f, -0.5f,

        // bottom
        -0.5f, -0.5f, -0.5f,
         0.5f, -0.5f, -0.5f,
         0.5f, -0.5f,  0.5f,
         0.5f, -0.5f,  0.5f,
        -0.5f, -0.5f,  0.5f,
        -0.5f, -0.5f, -0.5f
    };

    GLuint VBO;
    glGenVertexArrays(1, &cubeVAO);
    glGenBuffers(1, &VBO);

    glBindVertexArray(cubeVAO);
    glBindBuffer(GL_ARRAY_BUFFER, VBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(vertices), vertices, GL_STATIC_DRAW);

    // Position attribute
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3*sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);

    glBindVertexArray(0);
}

void DroneView::initSphereGeometry() {
    if (sphereVAO != 0) return;

    const int stacks = 12;
    const int slices = 12;
    const float PI = 3.14159265359f;

    std::vector<float> verts;
    verts.reserve(stacks * slices * 6);

    // Build triangle strips for each stack
    for (int i = 0; i < stacks; i++) {
        float phi0 = PI * (-0.5f + (float)i / stacks);
        float phi1 = PI * (-0.5f + (float)(i+1) / stacks);

        float y0 = std::sin(phi0);
        float r0 = std::cos(phi0);
        float y1 = std::sin(phi1);
        float r1 = std::cos(phi1);

        for (int j = 0; j <= slices; j++) {
            float theta = 2.0f * PI * ((float)j / slices);
            float x = std::cos(theta);
            float z = std::sin(theta);

            verts.push_back(x * r0);
            verts.push_back(y0);
            verts.push_back(z * r0);

            verts.push_back(x * r1);
            verts.push_back(y1);
            verts.push_back(z * r1);
        }
    }

    sphereNumVerts = (int)verts.size() / 3;

    glGenVertexArrays(1, &sphereVAO);
    glGenBuffers(1, &sphereVBO);

    glBindVertexArray(sphereVAO);
    glBindBuffer(GL_ARRAY_BUFFER, sphereVBO);
    glBufferData(GL_ARRAY_BUFFER, sizeof(float)*verts.size(), verts.data(), GL_STATIC_DRAW);

    // Position attribute
    glVertexAttribPointer(0, 3, GL_FLOAT, GL_FALSE, 3*sizeof(float), (void*)0);
    glEnableVertexAttribArray(0);

    glBindVertexArray(0);
}

void DroneView::drawCube(const glm::mat4& model) {
    GLint modelLoc = glGetUniformLocation(shaderProgram, "model");
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    glBindVertexArray(cubeVAO);
    glDrawArrays(GL_TRIANGLES, 0, 36);
    glBindVertexArray(0);
}

void DroneView::drawSphere(const glm::mat4& model) {
    GLint modelLoc = glGetUniformLocation(shaderProgram, "model");
    glUniformMatrix4fv(modelLoc, 1, GL_FALSE, glm::value_ptr(model));

    glBindVertexArray(sphereVAO);
    glDrawArrays(GL_TRIANGLE_STRIP, 0, sphereNumVerts);
    glBindVertexArray(0);
}

void DroneView::drawDrone(const DroneModel& model) {
    if (!geometryInitialized) return;

    float propAngle = model.getPropAngle();
    float rollAngle = model.getRollAngle();
    float yaw = model.getYaw();
    float pitch = model.getPitch();
    glm::vec3 position = model.getPosition();

    float propRad = glm::radians(propAngle);
    float rollRad = glm::radians(rollAngle);
    float yawRad = glm::radians(yaw);
    float pitchRad = glm::radians(pitch);

    // Base transform
    glm::mat4 drone(1.0f);
    drone = glm::translate(drone, position);
    drone = glm::rotate(drone, yawRad, glm::vec3(0,1,0));
    drone = glm::rotate(drone, pitchRad, glm::vec3(1,0,0));
    drone = glm::rotate(drone, rollRad, glm::vec3(0,0,1));

    // Overall scale + slight upward shift
    drone = glm::scale(drone, glm::vec3(1.0f));
    drone = glm::translate(drone, glm::vec3(0.0f, 0.2f, 0.0f));

    glUseProgram(shaderProgram);
    GLint colorLoc = glGetUniformLocation(shaderProgram, "objectColor");

    // (A) BODY (pink)
    {
        glUniform3f(colorLoc, 1.0f, 0.4f, 0.7f);
        glm::mat4 body = glm::scale(drone, glm::vec3(1.6f, 0.5f, 1.0f));
        drawCube(body);
    }

    // (B) NOSE (yellow, sphere!)
    {
        glUniform3f(colorLoc, 1.0f, 1.0f, 0.0f);
        glm::mat4 nose = glm::translate(drone, glm::vec3(0.0f, 0.0f, 0.7f));
        nose = glm::scale(nose, glm::vec3(0.2f));
        drawSphere(nose);
    }

    // (C) ARMS (white)
    auto drawArm = [&](float xOff, float zOff) {
        glm::mat4 arm = glm::translate(drone, glm::vec3(xOff, 0.0f, zOff));
        arm = glm::scale(arm, glm::vec3(0.7f, 0.1f, 0.1f));
        drawCube(arm);
    };

    glUniform3f(colorLoc, 1.0f, 1.0f, 1.0f);
    drawArm(-0.9f, +0.5f); // front-left
    drawArm(+0.9f, +0.5f); // front-right
    drawArm(-0.9f, -0.5f); // back-left
    drawArm(+0.9f, -0.5f); // back-right

    // (D) PROPELLERS (red)
    auto drawPropeller = [&](float xOff, float zOff) {
        float propX = xOff + (xOff < 0 ? -0.45f : +0.45f);

        // hub
        glm::mat4 hub = glm::translate(drone, glm::vec3(propX, 0.1f, zOff));
        hub = glm::rotate(hub, propRad, glm::vec3(0,1,0));
        hub = glm::scale(hub, glm::vec3(0.1f));
        drawCube(hub);

        // 4 blades
        for(int i=0; i<4; i++) {
            glm::mat4 blade = glm::translate(drone, glm::vec3(propX, 0.1f, zOff));
            blade = glm::rotate(blade, propRad, glm::vec3(0,1,0));
            blade = glm::rotate(blade, glm::radians(90.0f * i), glm::vec3(0,1,0));
            blade = glm::translate(blade, glm::vec3(0.0f, 0.0f, 0.2f));
            blade = glm::scale(blade, glm::vec3(0.05f, 0.02f, 0.35f));
            drawCube(blade);
        }
    };

    // red props
    glUniform3f(colorLoc, 1.0f, 0.0f, 0.0f);
    drawPropeller(-0.9f, +0.5f);
    drawPropeller(+0.9f, +0.5f);
    drawPropeller(-0.9f, -0.5f);
    drawPropeller(+0.9f, -0.5f);

    // (E) LEGS (white)
    auto drawLeg = [&](float xOff, float zOff) {
        glm::mat4 leg = glm::translate(drone, glm::vec3(xOff, -0.3f, zOff));
        leg = glm::scale(leg, glm::vec3(0.1f, 0.4f, 0.1f));
        drawCube(leg);
    };

    glUniform3f(colorLoc, 1.0f, 1.0f, 1.0f);
    drawLeg(-0.5f, +0.3f);
    drawLeg(+0.5f, +0.3f);
    drawLeg(-0.5f, -0.3f);
    drawLeg(+0.5f, -0.3f);
}

void DroneView::setCameraMode(CameraMode mode) {
    currentCamera = mode;
}

DroneView::CameraMode DroneView::getCameraMode() const {
    return currentCamera;
}

void DroneView::updateCamera(float dt, const DroneModel& model) {
    // Update chopper angle for the orbit camera
    chopperAngle += chopperSpeed * dt;
    if (chopperAngle > 360.0f)
        chopperAngle = fmod(chopperAngle, 360.0f);
}

glm::mat4 DroneView::getViewMatrix(const DroneModel& model) {
    // Get current camera position based on the camera mode
    switch(currentCamera) {
    // CAMERA_ANGLED = angled vantage at startup
    case CAMERA_ANGLED:
    {
        glm::vec3 camPos(6.0f, 3.0f, 6.0f);
        glm::vec3 target(0.0f, 1.0f, 0.0f);
        glm::vec3 up(0.0f, 1.0f, 0.0f);
        return glm::lookAt(camPos, target, up);
    }
    // CAMERA_TOP_DOWN = strict top-down
    case CAMERA_TOP_DOWN:
    {
        glm::vec3 camPos(0.0f, 15.0f, 0.0f);
        glm::vec3 target(0.0f, 0.0f, 0.0f);
        glm::vec3 up(0.0f, 0.0f, -1.0f);
        return glm::lookAt(camPos, target, up);
    }
    // CAMERA_ORBIT = overhead "chopper" orbit
    case CAMERA_ORBIT:
    {
        float radius = 10.0f;
        float x = radius * cos(glm::radians(chopperAngle));
        float z = radius * sin(glm::radians(chopperAngle));
        glm::vec3 camPos(x, 8.0f, z);
        glm::vec3 target(0.0f, 0.0f, 0.0f);
        glm::vec3 up(0.0f, 1.0f, 0.0f);
        return glm::lookAt(camPos, target, up);
    }
    // CAMERA_FIRST_PERSON = first-person from the drone's nose
    case CAMERA_FIRST_PERSON:
    {
        // Build the forward direction from yaw & pitch
        glm::vec3 forward = getForwardVector(model.getYaw(), model.getPitch());
        
        // Move the camera forward and shift it down a bit
        glm::vec3 camPos = model.getPosition()
                         + forward * 1.2f
                         + glm::vec3(0.0f, -0.3f, 0.0f);

        // The camera looks in the same direction
        glm::vec3 target = camPos + forward;

        // Compute 'up' from yaw/pitch
        glm::mat4 rot(1.0f);
        rot = glm::rotate(rot, glm::radians(model.getYaw()), glm::vec3(0,1,0));
        rot = glm::rotate(rot, glm::radians(model.getPitch()), glm::vec3(1,0,0));
        glm::vec3 up = glm::vec3(rot * glm::vec4(0,1,0,0));

        return glm::lookAt(camPos, target, up);
    }
    default:
        // Fallback (same as CAMERA_ANGLED)
        glm::vec3 camPos(6.0f, 3.0f, 6.0f);
        glm::vec3 target(0.0f, 1.0f, 0.0f);
        glm::vec3 up(0.0f, 1.0f, 0.0f);
        return glm::lookAt(camPos, target, up);
    }
}

glm::mat4 DroneView::getProjectionMatrix(int windowWidth, int windowHeight) {
    return glm::perspective(
        glm::radians(45.0f),
        (float)windowWidth / (float)windowHeight,
        0.1f, 100.0f
    );
}

glm::vec3 DroneView::getForwardVector(float yawDeg, float pitchDeg) {
    // If yaw=0 => facing +Z in local space
    glm::vec3 baseForward(0.0f, 0.0f, 1.0f);
    glm::mat4 transform(1.0f);

    // Yaw around Y, then pitch around X
    transform = glm::rotate(transform, glm::radians(yawDeg), glm::vec3(0,1,0));
    transform = glm::rotate(transform, glm::radians(pitchDeg), glm::vec3(1,0,0));

    glm::vec4 dir4 = transform * glm::vec4(baseForward, 0.0f);
    return glm::normalize(glm::vec3(dir4));
}

void View::initShaders() {
    const char* vertexSource = "..."; // Your vertex shader source
    const char* fragmentSource = "..."; // Your fragment shader source
    shaderProgram = createShaderProgram(vertexSource, fragmentSource);
}

void DroneView::render(const DroneModel& model, int windowWidth, int windowHeight) {
    // Clear
    glClearColor(0.12f, 0.12f, 0.2f, 1.0f);
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

    // Use shader
    glUseProgram(shaderProgram);

    // Set view matrix
    glm::mat4 view = getViewMatrix(model);
    GLint viewLoc = glGetUniformLocation(shaderProgram, "view");
    glUniformMatrix4fv(viewLoc, 1, GL_FALSE, glm::value_ptr(view));

    // Set projection matrix
    glm::mat4 projection = getProjectionMatrix(windowWidth, windowHeight);
    GLint projLoc = glGetUniformLocation(shaderProgram, "projection");
    glUniformMatrix4fv(projLoc, 1, GL_FALSE, glm::value_ptr(projection));

    // Draw the drone
    drawDrone(model);
}

void DroneView::cleanup() {
    if (cubeVAO != 0) {
        glDeleteVertexArrays(1, &cubeVAO);
        cubeVAO = 0;
    }
    if (sphereVAO != 0) {
        glDeleteVertexArrays(1, &sphereVAO);
        sphereVAO = 0;
    }
    if (sphereVBO != 0) {
        glDeleteBuffers(1, &sphereVBO);
        sphereVBO = 0;
    }
    if (shaderProgram != 0) {
        glDeleteProgram(shaderProgram);
        shaderProgram = 0;
    }
    
    geometryInitialized = false;
}
